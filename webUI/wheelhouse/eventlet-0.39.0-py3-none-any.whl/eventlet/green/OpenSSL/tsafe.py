from OpenSSL.tsafe import *
